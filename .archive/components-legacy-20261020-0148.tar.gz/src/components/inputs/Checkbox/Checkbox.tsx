import { resolveSurface, resolveBorder, resolveInteractionVars, ROLE_LEVEL } from '../../../engine/liminal-surface';
import { useHostSurface } from '../../../engine/liminal-surface-context';
import React from 'react';
import type { CSSProperties, KeyboardEvent, ChangeEvent } from 'react';
import { getLadderVar, getTextStyle } from '../../../engine/spec-engine';
import { LiminalColorEngine } from '../../../engine/liminal-color-engine';
import { LiminalLayoutEngine } from '../../../engine/liminal-layout-engine';
import { LiminalMotionEngine } from '../../../engine/liminal-motion-engine';
import { ICON_SIZES } from '../../../engine/liminal-icon-engine';

export interface CheckboxProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
  label?: string;
  description?: string;
  /**
   * The validation message.
   *
   * A checkbox validates: "you must accept the terms" is a real error, and it
   * was the one thing the other five inputs had and this did not. It is a
   * STRING, not a boolean — an error the reader cannot read is a red box.
   */
  error?: string;
  id?: string;
  name?: string;
  className?: string;
  style?: CSSProperties;
}

export function Checkbox({
  checked,
  onChange,
  disabled = false,
  label,
  description,
  error,
  id,
  name,
  className = '',
  style: customStyle = {},
}: CheckboxProps) {
  const SPACING = LiminalLayoutEngine.SPACING;
  const RADIUS = LiminalLayoutEngine.RADIUS;
  const TYPOGRAPHY = LiminalLayoutEngine.TYPOGRAPHY;
  const SEMANTICS = LiminalColorEngine.SEMANTICS;

  // The fill an unselected control rests in: a named role, not a hand-picked pair.
  const offRim = resolveSurface({ role: 'well' }).rimColors;

  const host = useHostSurface();

  const errorId = error ? `${id ?? name ?? 'checkbox'}-error` : undefined;

  // An error is a semantic state, not a colour choice: the engine's danger
  // tint, the same one the other inputs use.
  const boxBg = error
    ? SEMANTICS.DANGER.subtle
    : checked
    ? SEMANTICS.SUCCESS.subtle
    : offRim
    ? offRim.cssBackground
    : getLadderVar(ROLE_LEVEL.well);

  const boxStyle: CSSProperties = {
    width: ICON_SIZES.md,
    height: ICON_SIZES.md,
    borderRadius: `${RADIUS.chip}px`, // 6px
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    boxSizing: 'border-box',
    transition: LiminalMotionEngine.TRANSITION.normal,
    // The layer owns the surface — see data-liminal-surface. An inline
    // background beats the CSS rule, so this line cancelled the hover.
    //
    // A CHECKED box keeps its fill in EVERY state; an unchecked one lifts on
    // hover and sinks below its rest on press.
    ...resolveInteractionVars({
      role: 'control',
      on: host,
      idle: boxBg,
      frozen: checked ? boxBg : undefined,
    }),
    border: checked
      ? `1px solid ${SEMANTICS.SUCCESS.border}`
      : offRim
      ? '1px solid transparent'
      : `1px solid ${resolveBorder({ role: 'well', kind: 'edge' })}`,
  } as CSSProperties;

  const labelStyle: CSSProperties = {
    color: getTextStyle('secondary', 2).color,
    fontSize: LiminalLayoutEngine.getTypeSizeCss(2), // 13px
    fontWeight: 400,
    lineHeight: TYPOGRAPHY[2].lh,
    userSelect: 'none',
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLLabelElement>) => {
    if (disabled) return;
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      onChange(!checked);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (!disabled) {
      onChange(e.target.checked);
    }
  };

  return (
    <label
      htmlFor={id}
      onKeyDown={handleKeyDown}
      // The browser knows whether focus came from a keyboard. Hand-rolled Tab
      // tracking could not see Shift+Tab, programmatic focus, or a screen
      // reader moving the cursor — and it was a second copy of what
      // :focus-visible already does correctly.
      data-liminal-focusable=""
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: `${SPACING[2]}px`, // 8px
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        userSelect: 'none',
        boxSizing: 'border-box',
        // NO `outline: none` here. An inline style beats a CSS rule, so it
        // would silently cancel the layer's :focus-visible ring — which is
        // exactly what the eye test caught. The layer owns focus now.
        ...customStyle,
      }}
    >
      <input
        type="checkbox"
        id={id}
        name={name}
        checked={checked}
        disabled={disabled}
        onChange={handleChange}
        aria-invalid={error ? true : undefined}
        aria-describedby={errorId}
        tabIndex={disabled ? -1 : 0}
        style={{
          position: 'absolute',
          opacity: 0,
          width: 0,
          height: 0,
          pointerEvents: 'none',
        }}
      />

      <span data-liminal-surface="" style={boxStyle}>
        <svg
          width="12"
          height="12"
          viewBox="0 0 12 12"
          fill="none"
          style={{
            transform: checked ? 'scale(1)' : 'scale(0)',
            transition: LiminalMotionEngine.getTransition('transform', 'normal', 'spring'),
            color: SEMANTICS.SUCCESS.solid,
          }}
        >
          <path
            d="M2.5 6.2L4.8 8.5L9.5 3.8"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>

      {label && (
        <span style={{ display: 'flex', flexDirection: 'column' }}>
          <span style={labelStyle}>{label}</span>
          {/* The error REPLACES the description: two lines under one control
              is a paragraph, and the reader needs the one that says what is
              wrong. */}
          {error ? (
            <span
              id={errorId}
              role="alert"
              style={{ ...LiminalLayoutEngine.getTypeStyle(1), color: SEMANTICS.DANGER.text, marginTop: `${SPACING[0]}px` }}
            >
              {error}
            </span>
          ) : (
            description && (
              <span style={{ ...LiminalLayoutEngine.getTypeStyle(1), color: getTextStyle('tertiary', 1).color, marginTop: `${SPACING[0]}px` }}>
                {description}
              </span>
            )
          )}
        </span>
      )}
    </label>
  );
}

export default Checkbox;
