import React from 'react';
import type { CSSProperties } from 'react';
import { getLadderColor } from '../../../engine/spec-engine';
import { LiminalLayoutEngine } from '../../../engine/liminal-layout-engine';
import { useReducedMotion } from '../../../engine/liminal-hooks';
import { resolveSurface } from '../../../engine/liminal-surface';

export interface SkeletonProps {
  variant?: 'text' | 'title' | 'circle' | 'card' | 'custom';
  width?: string | number;
  height?: string | number;
  count?: number;
  borderRadius?: number;
  className?: string;
  style?: CSSProperties;
}

export function Skeleton({
  variant = 'text',
  width,
  height,
  count = 1,
  borderRadius,
  className = '',
  style: customStyle = {},
}: SkeletonProps) {
  const reduced = useReducedMotion();
  const SPACING = LiminalLayoutEngine.SPACING;
  const RADIUS = LiminalLayoutEngine.RADIUS;

  const s2Color = resolveSurface({ role: 'work' }).background;
  const s25Color = resolveSurface({ role: 'work', state: 'hover' }).background;

  // Dimensions by variant
  let defWidth: string | number = '100%';
  let defHeight: string | number = '12px';
  let defRadius: number | string = `${RADIUS.chip}px`; // 6px

  switch (variant) {
    case 'text':
      defWidth = '100%';
      defHeight = '12px';
      defRadius = `${RADIUS.chip}px`; // 6px
      break;
    case 'title':
      defWidth = '40%';
      defHeight = '20px';
      defRadius = `${RADIUS.chip}px`; // 6px
      break;
    case 'circle':
      defWidth = '44px';
      defHeight = '44px';
      defRadius = '50%';
      break;
    case 'card':
      defWidth = '100%';
      defHeight = '120px';
      defRadius = `${RADIUS.card}px`; // 16px
      break;
    case 'custom':
      defWidth = width ?? '100%';
      defHeight = height ?? `${LiminalLayoutEngine.SPACING[4]}px`;
      defRadius = borderRadius !== undefined ? `${borderRadius}px` : `${RADIUS.control}px`;
      break;
  }

  const finalWidth = width !== undefined ? (typeof width === 'number' ? `${width}px` : width) : defWidth;
  const finalHeight = height !== undefined ? (typeof height === 'number' ? `${height}px` : height) : defHeight;
  const finalRadius = borderRadius !== undefined ? `${borderRadius}px` : defRadius;

  const baseItemStyle: CSSProperties = {
    width: finalWidth,
    height: finalHeight,
    borderRadius: finalRadius,
    background: s2Color,
    animation: reduced ? 'none' : 'liminal-skeleton-pulse 1.6s ease-in-out infinite',
    boxSizing: 'border-box',
    border: 'none',
    boxShadow: 'none',
    flexShrink: 0,
    ...customStyle,
  };

  const renderSingle = (key?: number) => (
    <div
      key={key}
      className={`liminal-skeleton ${className}`}
      style={baseItemStyle}
      aria-busy="true"
      aria-label="Loading"
      role="status"
    />
  );

  if (count > 1) {
    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: `${SPACING[2]}px`, // 8px
          width: typeof finalWidth === 'string' && finalWidth.includes('%') ? finalWidth : '100%',
        }}
      >
        {Array.from({ length: count }).map((_, i) => renderSingle(i))}
      </div>
    );
  }

  return renderSingle();
}

export default Skeleton;
