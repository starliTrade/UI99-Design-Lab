import React, { useState } from 'react';
import type { CSSProperties } from 'react';
import { Topbar } from './Topbar';
import { Sidebar } from './Sidebar';
import { NavItem } from './NavItem';
import { Tabs } from './Tabs';
import { Breadcrumb } from './Breadcrumb';
import { Card } from '../containers/Card';
import { Button } from '../atoms/Button';
import { Badge } from '../atoms/Badge';
import { Input } from '../inputs/Input';
import {
  getTextStyle,
  getLadderColor,
} from '../../engine/spec-engine';
import { LiminalLayoutEngine } from '../../engine/liminal-layout-engine';
import { LiminalColorEngine } from '../../engine/liminal-color-engine';
import { LiminalMotionEngine } from '../../engine/liminal-motion-engine';
import {
  Compass,
  SquaresFour,
  Shield,
  Pulse,
  HardDrives,
  Gear,
  MagnifyingGlass,
  ArrowSquareOut,
  Cpu,
  Radio,
  WifiHigh,
  CaretDown,
  Trash,
  Copy,
  PencilSimple,
  Sliders,
  DownloadSimple,
  BellSimple,
  DotsThreeVertical,
} from '@phosphor-icons/react';
import { LiminalIcon } from '../../engine/liminal-icon-engine';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuShortcut,
} from './DropdownMenu';
import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuLabel,
  ContextMenuShortcut,
} from './ContextMenu';
import { resolveSurface } from '../../engine/liminal-surface';

export function NavDemo() {
  const [activeNav, setActiveNav] = useState<string>('gateways');
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [searchVal, setSearchVal] = useState<string>('');
  const [notifyOnAlert, setNotifyOnAlert] = useState<boolean>(true);
  const [realtimeTelemetry, setRealtimeTelemetry] = useState<boolean>(false);
  const [compressionAlgo, setCompressionAlgo] = useState<string>('lz4');

  const SPACING = LiminalLayoutEngine.SPACING;
  const RADIUS = LiminalLayoutEngine.RADIUS;
  const TYPOGRAPHY = LiminalLayoutEngine.TYPOGRAPHY;
  const SEMANTICS = LiminalColorEngine.SEMANTICS;

  const containerStyle = resolveSurface({ role: 'chrome', interactive: false }).style;

  const breadcrumbItems = [
    { label: 'Infrastructure', href: '#infra' },
    { label: 'Edge Gateways', href: '#gateways' },
    { label: 'Cluster Alpha (H230)', active: true },
  ];

  return (
    <div
      style={{
        ...containerStyle,
        borderRadius: `${RADIUS.container}px`,
        padding: 0,
        overflow: 'hidden',
        boxSizing: 'border-box',
      }}
      className="space-y-0"
    >
      {/* 1. TOPBAR */}
      <Topbar
        sticky={false}
        logo={
          <div className="flex items-center gap-2">
            <span
              style={{
                width: '28px',
                height: '28px',
                borderRadius: `${RADIUS.chip}px`,
                background: 'rgba(233, 236, 242, 0.10)',
                border: '1px solid rgba(233, 236, 242, 0.22)',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: LiminalColorEngine.BRAND_PRIMARY.hex,
              }}
            >
              <LiminalIcon icon={Compass} size="sm" weight="light" />
            </span>
            <span
              style={{
                fontSize: `${TYPOGRAPHY[3].fs}px`,
                fontWeight: 600,
                color: getTextStyle('primary', 1).color,
                letterSpacing: '-0.01em',
              }}
            >
              LIMINAL NAV
            </span>
            <Badge semantic="info">v1.0</Badge>
          </div>
        }
        actions={
          <div className="flex items-center gap-3">
            <div style={{ width: '180px' }} className="hidden sm:block">
              <Input
                type="search"
                placeholder="Quick jump..."
                value={searchVal}
                onChange={(e) => setSearchVal(e.target.value)}
                prefix={<LiminalIcon icon={MagnifyingGlass} size="xs" weight="light" />}
              />
            </div>
            <div
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '50%',
                background: 'rgba(255, 255, 255, 0.08)',
                border: '1px solid rgba(255, 255, 255, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '12px',
                fontFamily: 'monospace',
                color: getTextStyle('primary', 1).color,
              }}
            >
              L8
            </div>
            <Button size="sm" variant="primary">
              Deploy Route
            </Button>
          </div>
        }
      >
        <NavItem active={activeNav === 'gateways'} onClick={() => setActiveNav('gateways')}>
          Gateways
        </NavItem>
        <NavItem active={activeNav === 'security'} onClick={() => setActiveNav('security')}>
          Perimeters
        </NavItem>
        <NavItem active={activeNav === 'telemetry'} onClick={() => setActiveNav('telemetry')}>
          Telemetry
        </NavItem>
        <NavItem active={activeNav === 'system'} onClick={() => setActiveNav('system')}>
          Settings
        </NavItem>
      </Topbar>

      {/* 2. BODY LAYOUT: SIDEBAR + MAIN AREA */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'row',
          gap: `${SPACING[5]}px`,
          padding: `${SPACING[5]}px`,
          boxSizing: 'border-box',
          minHeight: '480px',
        }}
        className="flex-col md:flex-row"
      >
        {/* SIDEBAR */}
        <Sidebar width={230} sticky={false}>
          <Sidebar.Section label="Topology Nodes">
            <NavItem
              active={activeNav === 'gateways'}
              onClick={() => setActiveNav('gateways')}
            >
              <LiminalIcon icon={SquaresFour} size="sm" weight="light" />
              <span>Gateway Clusters</span>
            </NavItem>

            <NavItem
              active={activeNav === 'security'}
              onClick={() => setActiveNav('security')}
            >
              <LiminalIcon icon={Shield} size="sm" weight="light" />
              <span>Security Shards</span>
            </NavItem>

            <NavItem
              active={activeNav === 'telemetry'}
              onClick={() => setActiveNav('telemetry')}
            >
              <LiminalIcon icon={Pulse} size="sm" weight="light" />
              <span>Telemetry Streams</span>
            </NavItem>
          </Sidebar.Section>

          <Sidebar.Section label="Node Configuration">
            <NavItem
              active={activeNav === 'servers'}
              onClick={() => setActiveNav('servers')}
            >
              <LiminalIcon icon={HardDrives} size="sm" weight="light" />
              <span>Hardware Root</span>
            </NavItem>

            <NavItem
              active={activeNav === 'system'}
              onClick={() => setActiveNav('system')}
            >
              <LiminalIcon icon={Gear} size="sm" weight="light" />
              <span>System Preferences</span>
            </NavItem>

            <NavItem disabled>
              <LiminalIcon icon={ArrowSquareOut} size="sm" weight="light" />
              <span>Audit Vault (Offline)</span>
            </NavItem>
          </Sidebar.Section>
        </Sidebar>

        {/* MAIN AREA */}
        <div style={{ flex: 1, minWidth: 0 }} className="space-y-4">
          {/* Breadcrumb row */}
          <div className="flex items-center justify-between pb-1">
            <Breadcrumb items={breadcrumbItems} />
            <div className="flex items-center gap-2">
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  background: SEMANTICS.SUCCESS.solid,
                }}
              />
              <span
                style={{
                  fontSize: '11px',
                  fontFamily: 'monospace',
                  color: SEMANTICS.SUCCESS.text,
                }}
              >
                QUORUM SYNCHRONIZED
              </span>
            </div>
          </div>

          {/* Page Title & Subtitle */}
          <div>
            <h1
              style={{
                fontSize: `${TYPOGRAPHY[5].fs}px`,
                fontWeight: 600,
                color: getTextStyle('primary', 1).color,
                margin: 0,
              }}
            >
              Cluster Alpha Operations
            </h1>
            <p
              style={{
                fontSize: `${TYPOGRAPHY[2].fs}px`,
                color: getTextStyle('secondary', 1).color,
                marginTop: '4px',
                margin: 0,
              }}
            >
              Realtime ingress telemetry with dual-penumbra tabs and directional illumination.
            </p>
          </div>

          {/* TABS (Surface 1 container with Surface 3 Active + Micro E1 Shadow) */}
          <div className="pt-1">
            <Tabs value={activeTab} onChange={setActiveTab}>
              <Tabs.Tab value="overview">Overview Matrix</Tabs.Tab>
              <Tabs.Tab value="listeners">Active Listeners</Tabs.Tab>
              <Tabs.Tab value="certificates">TLS Certificates</Tabs.Tab>
              <Tabs.Tab value="quarantine" disabled>Quarantine Shard</Tabs.Tab>
            </Tabs>
          </div>

          {/* CARDS GRID */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <Card title="Ingress Rate" padding="md">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span style={{ fontSize: '11px', color: getTextStyle('tertiary', 1).color }}>
                    PEAK THROUGHPUT
                  </span>
                  <LiminalIcon icon={WifiHigh} size="xs" weight="light" color={SEMANTICS.INFO.text} />
                </div>
                <div
                  style={{
                    fontSize: '23px',
                    fontWeight: 600,
                    color: getTextStyle('primary', 1).color,
                  }}
                >
                  842.1 MB/s
                </div>
                <div style={{ fontSize: '11px', color: SEMANTICS.SUCCESS.text }}>
                  +14.2% versus baseline
                </div>
              </div>
            </Card>

            <Card title="Edge Microcode" padding="md">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span style={{ fontSize: '11px', color: getTextStyle('tertiary', 1).color }}>
                    ACTIVE KERNEL
                  </span>
                  <LiminalIcon icon={Cpu} size="xs" weight="light" color={LiminalColorEngine.BRAND_PRIMARY.hex} />
                </div>
                <div
                  style={{
                    fontSize: '23px',
                    fontWeight: 600,
                    color: getTextStyle('primary', 1).color,
                  }}
                >
                  v4.19-lim
                </div>
                <div style={{ fontSize: '11px', color: getTextStyle('tertiary', 1).color }}>
                  Zero page faults detected
                </div>
              </div>
            </Card>

            <Card title="Transport Anycast" padding="md">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span style={{ fontSize: '11px', color: getTextStyle('tertiary', 1).color }}>
                    SYNCHRONIZATION
                  </span>
                  <LiminalIcon icon={Radio} size="xs" weight="light" color={SEMANTICS.SUCCESS.solid} />
                </div>
                <div
                  style={{
                    fontSize: '23px',
                    fontWeight: 600,
                    color: SEMANTICS.SUCCESS.text,
                  }}
                >
                  3.2 ms
                </div>
                <div style={{ fontSize: '11px', color: getTextStyle('quaternary', 1).color }}>
                  Direct BGP peer established
                </div>
              </div>
            </Card>
          </div>

          {/* 5. DROPDOWN MENU SHOWCASE (Phase 6.1) */}
          <div
            style={{
              marginTop: `${SPACING[5]}px`,
              padding: `${SPACING[4]}px`,
              borderRadius: `${RADIUS.card}px`,
              background: getLadderColor(1.5),
              border: `1px solid ${getLadderColor(2.5)}`,
              boxSizing: 'border-box',
            }}
            className="space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div
                  style={{
                    fontSize: `${TYPOGRAPHY[3].fs}px`,
                    fontWeight: 600,
                    color: getTextStyle('primary', 1).color,
                  }}
                >
                  Dropdown Menus & Composition
                </div>
                <div
                  style={{
                    fontSize: `${TYPOGRAPHY[1].fs}px`,
                    color: getTextStyle('tertiary', 1).color,
                    marginTop: '2px',
                  }}
                >
                  Radix-style Slot composition · Portal rendering · Floating flip/shift · Phosphor icons
                </div>
              </div>
              <Badge semantic="info">PHASE 6.1 COMPLIANT</Badge>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              {/* Menu 1: Cluster Actions with asChild Button, icons, shortcuts, danger variant */}
              <DropdownMenu placement="bottom-start">
                <DropdownMenuTrigger asChild>
                  <Button variant="secondary" size="sm">
                    <span>Cluster Actions</span>
                    <LiminalIcon icon={CaretDown} size="xs" weight="bold" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent minWidth={210}>
                  <DropdownMenuLabel>Cluster Commands</DropdownMenuLabel>
                  <DropdownMenuItem
                    icon={<LiminalIcon icon={PencilSimple} size="sm" />}
                    shortcut="⌘E"
                    onClick={() => console.warn('Edit cluster requested')}
                  >
                    Edit Shard Topology
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    icon={<LiminalIcon icon={Copy} size="sm" />}
                    shortcut="⌘C"
                    onClick={() => console.warn('Duplicate cluster requested')}
                  >
                    Clone Node Spec
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    icon={<LiminalIcon icon={DownloadSimple} size="sm" />}
                    shortcut="⇧⌘D"
                    onClick={() => console.warn('Export config requested')}
                  >
                    Export Snapshot
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>Maintenance</DropdownMenuLabel>
                  <DropdownMenuItem disabled icon={<LiminalIcon icon={Sliders} size="sm" />}>
                    Hot Re-index (Busy)
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    variant="danger"
                    icon={<LiminalIcon icon={Trash} size="sm" />}
                    shortcut="⌘⌫"
                    onClick={() => console.warn('Purge cluster requested')}
                  >
                    Purge Node Shard
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Menu 2: Stream Preferences with Checkboxes & Radios */}
              <DropdownMenu placement="bottom-start">
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <LiminalIcon icon={Sliders} size="xs" />
                    <span>Stream Settings</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent minWidth={220}>
                  <DropdownMenuLabel>Realtime Filters</DropdownMenuLabel>
                  <DropdownMenuCheckboxItem
                    checked={notifyOnAlert}
                    onCheckedChange={setNotifyOnAlert}
                    shortcut="⇧A"
                  >
                    Notify on Anomaly
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={realtimeTelemetry}
                    onCheckedChange={setRealtimeTelemetry}
                    shortcut="⇧T"
                  >
                    Telemetry Sync
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel>Compression Engine</DropdownMenuLabel>
                  <DropdownMenuRadioGroup
                    value={compressionAlgo}
                    onValueChange={setCompressionAlgo}
                  >
                    <DropdownMenuRadioItem value="lz4" shortcut="LZ4">
                      LZ4 (Ultra Fast)
                    </DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="zstd" shortcut="ZSTD">
                      Zstandard (Balanced)
                    </DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="snappy" shortcut="SNP">
                      Snappy (Low Latency)
                    </DropdownMenuRadioItem>
                  </DropdownMenuRadioGroup>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Menu 3: Overflow Ghost Button with asChild */}
              <DropdownMenu placement="bottom-end">
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" aria-label="More options">
                    <LiminalIcon icon={DotsThreeVertical} size="sm" weight="bold" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent minWidth={180}>
                  <DropdownMenuLabel>Quick Links</DropdownMenuLabel>
                  <DropdownMenuItem icon={<LiminalIcon icon={BellSimple} size="sm" />}>
                    View Alerts
                  </DropdownMenuItem>
                  <DropdownMenuItem icon={<LiminalIcon icon={Gear} size="sm" />}>
                    Kernel Config
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    asChild
                    onClick={() => console.warn('Audit logs opened')}
                  >
                    <a
                      href="#audit-logs"
                      style={{ display: 'flex', alignItems: 'center', gap: `${SPACING[2]}px` }}
                    >
                      <LiminalIcon icon={ArrowSquareOut} size="sm" />
                      <span>Audit Logs (Anchor)</span>
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Status pill showing current selected radio & checkbox */}
              <div
                style={{
                  fontSize: `${TYPOGRAPHY[1].fs}px`,
                  fontFamily: 'monospace',
                  color: getTextStyle('secondary', 1).color,
                  padding: `${SPACING[1]}px ${SPACING[2]}px`,
                  borderRadius: `${RADIUS.chip}px`,
                  background: getLadderColor(2),
                  border: `1px solid ${getLadderColor(2.5)}`,
                }}
                className="hidden lg:inline-flex items-center gap-2"
              >
                <span>Compression: <strong>{compressionAlgo.toUpperCase()}</strong></span>
                <span>·</span>
                <span>Alerts: <strong>{notifyOnAlert ? 'ON' : 'OFF'}</strong></span>
                <span>·</span>
                <span>Sync: <strong>{realtimeTelemetry ? 'ON' : 'OFF'}</strong></span>
              </div>
            </div>
          </div>

          {/* 6. CONTEXT MENU SHOWCASE (Phase 6.2) */}
          <div
            style={{
              padding: `${SPACING[4]}px`,
              borderRadius: `${RADIUS.card}px`,
              background: getLadderColor(1.5),
              border: `1px solid ${getLadderColor(2.5)}`,
              boxSizing: 'border-box',
            }}
            className="space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div
                  style={{
                    fontSize: `${TYPOGRAPHY[3].fs}px`,
                    fontWeight: 600,
                    color: getTextStyle('primary', 1).color,
                  }}
                >
                  Context Menu (Right-Click Advanced)
                </div>
                <div
                  style={{
                    fontSize: `${TYPOGRAPHY[1].fs}px`,
                    color: getTextStyle('tertiary', 1).color,
                    marginTop: '2px',
                  }}
                >
                  Right-click anywhere on the target card below to invoke the virtual positioning context menu
                </div>
              </div>
              <Badge semantic="success">PHASE 6.2 ACTIVE</Badge>
            </div>

            <ContextMenu placement="bottom-start">
              <ContextMenuTrigger asChild>
                <div
                  style={{
                    padding: `${SPACING[5]}px`,
                    borderRadius: `${RADIUS.container}px`,
                    background: getLadderColor(2),
                    border: `1px dashed ${getLadderColor(3.5)}`,
                    textAlign: 'center',
                    cursor: 'context-menu',
                    userSelect: 'none',
                    transition: LiminalMotionEngine.TRANSITION.fast,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = LiminalColorEngine.BRAND_PRIMARY.hex;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = getLadderColor(3.5);
                  }}
                >
                  <div
                    style={{
                      fontSize: `${TYPOGRAPHY[4].fs}px`,
                      fontWeight: 600,
                      color: getTextStyle('primary', 1).color,
                      marginBottom: `${SPACING[1]}px`,
                    }}
                  >
                    📁 cluster-node-alpha-h230.shard
                  </div>
                  <div
                    style={{
                      fontSize: `${TYPOGRAPHY[2].fs}px`,
                      color: getTextStyle('tertiary', 1).color,
                    }}
                  >
                    [ Right-Click Here to Open Context Menu ]
                  </div>
                </div>
              </ContextMenuTrigger>
              <ContextMenuContent minWidth={210}>
                <ContextMenuLabel>Node Shard Operations</ContextMenuLabel>
                <ContextMenuItem
                  icon={<LiminalIcon icon={ArrowSquareOut} size="sm" />}
                  shortcut="↵"
                  onClick={() => console.warn('Open node shard requested')}
                >
                  Open Shard
                </ContextMenuItem>
                <ContextMenuItem
                  icon={<LiminalIcon icon={PencilSimple} size="sm" />}
                  shortcut="F2"
                  onClick={() => console.warn('Rename shard requested')}
                >
                  Rename Shard
                </ContextMenuItem>
                <ContextMenuSeparator />
                <ContextMenuItem
                  variant="danger"
                  icon={<LiminalIcon icon={Trash} size="sm" />}
                  shortcut="⌫"
                  onClick={() => console.warn('Delete shard requested')}
                >
                  Delete Shard
                </ContextMenuItem>
              </ContextMenuContent>
            </ContextMenu>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NavDemo;
