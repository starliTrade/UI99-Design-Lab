export { Spinner, default } from './Spinner';
export type { SpinnerProps } from './Spinner';
